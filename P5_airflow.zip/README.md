* [Goal](#Goal)
* [Datasets](#Datasets)
* [Project Setup to run locally](#Project-Setup-to-run-locally)
* [Database ETL pipeline](#Database-ETL-pipeline)
* [ETL pipeline design](#ETL-pipeline-design)
* [Summary](#Summary)
* -------------------------------------------

#### Goal

Goal is to design ETL Data Pipeline using airflow to run schedule timeline.

#### Datasets
There are two datasets that reside in S3. Here are the S3 links for each:
Song data: s3://udacity-dend/song_data
Log data: s3://udacity-dend/log_data
Song Dataset
song_data/A/B/C/TRABCEI128F424C983.json
song_data/A/A/B/TRAABJL12903CDCF1A.json
And below is an example of what a single song file, TRAABJL12903CDCF1A.json, looks like.
{"num_songs": 1, "artist_id": "ARJIE2Y1187B994AB7", "artist_latitude": null, "artist_longitude": null, "artist_location": "", "artist_name": "Line Renaud", "song_id": "SOUPIRU12A6D4FA1E1", "title": "Der Kleine Dompfaff", "duration": 152.92036, "year": 0}

Log Dataset

log_data/2018-11-12-events.json
log_data/2018-11-13-events.json

{"artist":"Girl Talk","auth":"Logged In","firstName":"Kaylee","gender":"F","itemInSession":8,"lastName":"Summers","length":160.15628,"level":"free","location":"Phoenix-Mesa-Scottsdale, AZ","method":"PUT","page":"NextSong","registration":1540344794796.0,"sessionId":139,"song":"Once again","status":200,"ts":1541107734796,"userAgent":"\"Mozilla\/5.0 (Windows NT 6.1; WOW64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/35.0.1916.153 Safari\/537.36\"","userId":"8"}


#### Project Setup to run locally

Install Airflow, create variable AIRFLOW_HOME and AIRFLOW_CONFIG with the appropiate paths, and place dags and plugins on airflor_home directory.
Initialize Airflow data base with airflow initdb, and open webserver with airflow webserver

Access the server http://localhost:8080
Configure AWS ConnId and redshift connection from airflow GUI to use it in dag.

DAG was configured to support the following requirements :

The DAG does not have dependencies on past runs
DAG has schedule interval set to hourly
On failure, the task are retried 3 times
Retries happen every 5 minutes
Catchup is turned off
Email are not sent on retry

--------------------------------------------

#### Database ETL pipeline

Fact Table

songplays - records in log data associated with song plays i.e. records with page NextSong

songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent

Dimension Tables
users - users in the app
user_id, first_name, last_name, gender, level

songs - songs in music database
song_id, title, artist_id, year, duration

artists - artists in music database
artist_id, name, location, lattitude, longitude

time - timestamps of records in songplays broken down into specific units
start_time, hour, day, week, month, year, weekday

#### ETL pipeline design

dags/udac_example_dag.py: Main dag for whole ETL process 
plugins/helpers/sql_queries.py: Insert SQL statements
plugins/operators/create_tables.sql: Create SQL statements
plugins/operators/stage_redshift.py: Operator that used to copy the data from S3 buckets into redshift staging tables
plugins/operators/load_dimension.py: Operator that used to load data from redshift staging tables into dimensional tables
plugins/operators/load_fact.py: Operator that used to load data from redshift staging tables into fact tables
plugins/operators/data_quality.py: Operator that used to check data quality of data load in target system

Following airflow custom Operators developed and used in ETL pipeline.

Stage operator:
1. Task to stage JSON/CSV data from S3 files to Amazon Redshift server, uses SQL copy statement to load the files into target system.
2. Task uses Dynamic sql during copy statement execution time.
3. Airfow hooks are used to connect to DB

Fact & Dimension Operators:
1. Dimension tables are loaded using LoadDimension operator. 
2. Fact tables are loaded using LoadFact operator.
3. Both opearators support historical/incremental loads.

DataQuality Operator:
1. Data quality checks are perfomed
2. Operator raises an error if it fails

#### Summary
Current airflow ETL pipeline help to ensure the data was loading properly into target database.
