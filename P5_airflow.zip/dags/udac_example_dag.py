from datetime import datetime, timedelta
import os
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators import (StageToRedshiftOperator, LoadFactOperator,
                                LoadDimensionOperator, DataQualityOperator)
from helpers import SqlQueries

# AWS_KEY = os.environ.get('AWS_KEY')
# AWS_SECRET = os.environ.get('AWS_SECRET')

default_args = {
    "owner": "udacity",
    "depends_on_past": False,
    "start_date": datetime(2019, 10, 8),
    "email_on_retry": False,
    "retry_delay": timedelta(minutes=5),
    "retries": 3
}

dag = DAG('udac_example_dag_1',
          default_args=default_args,
          description='Load and transform data in Redshift with Airflow',
          catchup = False,
          schedule_interval='@hourly'
        )

start_operator = DummyOperator(task_id="Begin_execution",  dag=dag)

stage_events_to_redshift = StageToRedshiftOperator(
    task_id="stage_events",
    dag=dag,
    table="staging_events",
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    s3_source="s3://udacity-dend/log_data",
    file_type="JSON",
    json_path = "s3://udacity-dend/log_json_path.json",
)

stage_songs_to_redshift = StageToRedshiftOperator(
    task_id="stage_songs",
    dag=dag,
    table="staging_songs",
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    s3_source="s3://udacity-dend/song_data/A/A/A",
    file_type="JSON",
    json_paths="auto"
)

load_songplays_table = LoadFactOperator(
    task_id="ld_songplays_fact_table",
    dag=dag,
    table="songplays",
    redshift_conn_id="redshift",
    load_sql_stmt=SqlQueries.songplay_table_insert
)

load_user_dimension_table = LoadDimensionOperator(
    task_id="ld_user_dim_table",
    dag=dag,
    table="users",
    redshift_conn_id="redshift",
    load_type="historical",
    load_sql_stmt=SqlQueries.user_table_insert
)

load_song_dimension_table = LoadDimensionOperator(
    task_id="ld_song_dim_table",
    dag=dag,
    table="songs",
    redshift_conn_id="redshift",
    load_type="historical",
    load_sql_stmt=SqlQueries.song_table_insert
)

load_artist_dimension_table = LoadDimensionOperator(
    task_id="ld_artist_dim_table",
    dag=dag,
    table="artists",
    redshift_conn_id="redshift",
    load_type="historical",
    load_sql_stmt=SqlQueries.artist_table_insert
)

load_time_dimension_table = LoadDimensionOperator(
    task_id="ld_time_dim_table",
    dag=dag,
    table="time",
    redshift_conn_id="redshift",
    load_type="historical",
    load_sql_stmt=SqlQueries.time_table_insert
)

run_quality_checks = DataQualityOperator(
    task_id="run_data_quality_checks",
    dag=dag,
    tables=["songs", "artists","users", "songplays",  "time"],
    redshift_conn_id="redshift"
)

end_operator = DummyOperator(task_id="Stop_execution",  dag=dag)

#
# Task ordering for the defined DAG tasks
#


start_operator.set_upstream([stage_events_to_redshift, stage_songs_to_redshift])
stage_events_to_redshift.set_upstream(load_songplays_table)
stage_songs_to_redshift.set_upstream(load_songplays_table)
load_songplays_table.set_upstream([load_user_dimension_table, load_song_dimension_table,load_artist_dimension_table, load_time_dimension_table])
load_user_dimension_table.set_upstream(run_quality_checks)
load_song_dimension_table.set_upstream(run_quality_checks)
load_artist_dimension_table.set_upstream(run_quality_checks)
load_time_dimension_table.set_upstream(run_quality_checks)
run_quality_checks.set_upstream(end_operator)

