from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 tables=[],
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.tables = tables
        self.redshift_conn_id = redshift_conn_id

    def execute(self, context):
        redshift_hook = PostgresHook(self.redshift_conn_id)
        for table in self.tables:
            self.log.info(f"DataQuality check is in-progress for {table} ")
            data_rows = redshift_hook.get_records(f"SELECT COUNT(*) FROM {table}")
            if len(data_rows) < 1 or len(data_rows[0]) < 1 or data_rows[0][0] < 1:
                self.log.error(f"Failed - DataQuality check for {table} returned no results")
                raise ValueError(f"Failed - DataQuality check for {table} returned no results")
            self.log.info(f"Passed - DataQuality check for table : {table} with {data_rows[0][0]} records")

