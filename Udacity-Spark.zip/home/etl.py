import configparser
from datetime import datetime
import os
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType, TimestampType,IntegerType
from pyspark.sql.functions import udf, col, to_timestamp
from pyspark.sql.functions import year, month, dayofmonth, hour, weekofyear, date_format


config = configparser.ConfigParser()
parser = config.read('dl.cfg')

os.environ['AWS_ACCESS_KEY_ID'] = config.get('CREDENTIALS', 'AWS_ACCESS_KEY_ID')
os.environ['AWS_SECRET_ACCESS_KEY'] = config.get('CREDENTIALS', 'AWS_SECRET_ACCESS_KEY')

def create_spark_session():
    """ Scanning Spark Components """
    spark = SparkSession         \
            .builder         \
            .master("local[*]")         \
            .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.0")   \
            .getOrCreate()
    return spark

def process_song_data(spark, input_data, output_data):
    # Processing song data set from S3 bucket
    song_data_schema =  StructType([
                        StructField("song_id", StringType(),True),
                        StructField("title", StringType(),True),        
                        StructField("year", IntegerType(),True),
                        StructField("duration", DoubleType(),True),
                        StructField("artist_id", StringType(),True),
                        StructField("artist_name", StringType(),True),
                        StructField("artist_location", StringType(), True),
                        StructField("artist_latitude", DoubleType(), True),
                        StructField("artist_longitude", DoubleType(), True)
                        ])
    # Assigning the song filepath
    song_data =  input_data + "song_data/*/*/*/*.json"
    
    # Read song JSON files using Spark read json API
    df = spark.read.json(song_data, schema=song_data_schema)

    # Assigning song column names
    song_fields = ["song_id","title AS song_title","artist_id","year","duration"]

    # extract required columns to create songs table
    exprs = ["{}".format(field,field) for field in song_fields]
    songs_table = df.selectExpr(*exprs)

    #Write songs data to parquet files partitioned by year and artist_id 
    songs_table.write.partitionBy('year','artist_id').parquet(output_data + "songs",mode='overwrite')
    
    # Assigning artist column names
    artist_fields = ["artist_id", "artist_name", "artist_location", "artist_latitude","artist_longitude"]

    # extract required columns to create aritist table
    exprs = ["{}".format(field,field) for field in artist_fields]
    artist_table = df.selectExpr(*exprs)
    #Write artists data to parquet files 
    artist_table.write.parquet(output_data + "artist",mode='overwrite')
    

def process_log_data(spark, input_data, output_data):
    # Processing song data set from S3 bucket
    log_data_schema =  StructType([
                        StructField("artist", StringType(), True),
                        StructField("auth", StringType(), True),
                        StructField("firstName", StringType(), True),
                        StructField("gender", StringType(), True),
                        StructField("itemInSession", IntegerType(), True),
                        StructField("lastName", StringType(), True),
                        StructField("length", DoubleType(), True),
                        StructField("level", StringType(), True),
                        StructField("location", StringType(), True),
                        StructField("method", StringType(), True),
                        StructField("page", StringType(), True),
                        StructField("registration", DoubleType(), True),
                        StructField("sessionId", IntegerType(), True),
                        StructField("song", StringType(), True),
                        StructField("status", IntegerType(), True),
                        StructField("ts", StringType(), True),
                        StructField("userAgent", StringType(), True),
                        StructField("userId", StringType(), True)
                        ])
    
    # Assigning the log filepath
    log_data =  input_data + "log_data/*.json"

    
    # Read song JSON files using Spark read json API
    df = spark.read.json(log_data, schema=log_data_schema)
    df = df.filter(col("page") == 'NextSong')

    # Assigning user column names
    user_fields = ["userId AS user_id","firstName AS first_name","lastName AS last_name","gender","level"]

    # extract required columns to create user table
    exprs = ["{}".format(field,field) for field in user_fields]
    user_table = df.selectExpr(*exprs)

    # Write users data to parquet files  
    user_table.write.parquet(output_data + "log",mode='overwrite')
    
    # timestamp conversion 
    timestamp_format = "yyyy-MM-dd HH:MM:ss z"
    
    time_table = df.withColumn('ts',to_timestamp(date_format((df.ts/1000).cast(dataType=TimestampType()), timestamp_format), timestamp_format))

    # Assigning time table column names
    time_fields = ["ts as start_time", "hour(ts) as hour","dayofmonth(ts) as day", "weekofyear(ts)  as week","month(ts) as month","year(ts) as year"]

    # extract required columns to create time table
    exprs = ["{}".format(field,field) for field in time_fields]
    time_table = time_table.selectExpr(*exprs)
        
    # write time data to parquet files partitioned by year and month 
    time_table.write.partitionBy('year','month').parquet(output_data + "time",mode='overwrite')
    
    # creating the song_df from parquet files
    song_df = spark.read.parquet(output_data+'songs')
    song_df.createOrReplaceTempView("songs")
    df.createOrReplaceTempView("log_events")
    
    songplay_table = spark.sql(""" 
    select 
    row_number() over (partition by from_unixtime(ts/1000,'YYYY-MM-dd HH:mm:ss') order by from_unixtime(ts/1000,'YYYY-mm-dd HH:MM:ss')) as songplay_id
    , from_unixtime(ts/1000,'YYYY-MM-dd HH:mm:ss') as start_time, l.userId
    , l.level, s.song_id, s.artist_id, l.sessionId, l.location, l.userAgent  
    from songs s 
    JOIN log_events l on s.song_title = l.song AND s.duration = l.length """) 
    
    # write song_plays table to parquet files partitioned by year and month
    songplay_table.select(col("*"), year('start_time').alias('year'),year('start_time').alias('month'))     .write.partitionBy('year','month').parquet(output_data + "song_plays",mode='overwrite')

def main():
    spark = create_spark_session()
    input_data = "s3a://udacity-dend/"
    output_data = "s3a://udacity-dend/"
    process_song_data(spark, input_data, output_data)    
    process_log_data(spark, input_data, output_data)
    
if __name__ == "__main__":
    main()

